#ifndef LIBS_H
#define LIBS_H

#include "headers/constants.h"
#include "headers/functions.h"
#include "headers/structures.h"

#endif